#!/bin/sh

cp ../../../lake.jpg lake-640x480-7.jpg
cp ../../../pirun.jpg pirun-640x640-27.jpg
cp ../../../van1.jpg van1-480x640-23-480x640-40.jpg
cp ../../../van2.jpg van2-640x480-92-640x480-87.jpg
cp ../../../van1.jpg van1-480x640-23.jpg
cp ../../../van2.jpg van2-640x480-92.jpg
cp ../../../angkor.jpg angkor-2004x1362-73.jpg

